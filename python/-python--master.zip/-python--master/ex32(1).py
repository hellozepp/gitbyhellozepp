elements = []
i = [1, 2, 3, 4]
for i in elements:
    print i
