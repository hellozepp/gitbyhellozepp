# -python-
学习《笨办法学python》练习代码
