﻿animals = ['bear', 'tiger', 'penguin', 'zebra']
bear = animals[0]

animals = ['bear', 'python', 'peacock', 'kangaroo', 'whale', 'platypus']
print '1. The animal at %s' % animals[1]
print '2. The %s animal.' % animals[2]
print '3. The %s animal.' % animals[0]
print '4. The animal at %s.' % animals[3]
print '5. The %s animal.' % animals[4]
print '6. The animal at %s.' % animals[2]
print '7. The %s animal.' % animals[5]
print '8. The animal at %s.\n' % animals[4]

word = raw_input("Please enter the word: \n> ")
if word == 'book':
    word = str(word)
    print "书"
