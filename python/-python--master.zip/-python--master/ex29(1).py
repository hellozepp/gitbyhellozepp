#people = 20
#cats = 30
#dogs = 15

if people < cats:
    print "Too many cats! The world is doomed!"

if True and False:
    print "0"
else:
    print "1"
