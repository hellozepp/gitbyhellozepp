from ex25 import *
sentence = "All good things come to those who wait."
words = break_words(sentence)
print words
