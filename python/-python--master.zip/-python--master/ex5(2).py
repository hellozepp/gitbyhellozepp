my_heightft = 74 
my_heightcm = 74 * 2.540005
my_weightlb = 180
my_weightkg = 180 * 0.454

print "He's %d cm tall." % my_heightcm
print "He's %d kg heavy." % my_weightkg
