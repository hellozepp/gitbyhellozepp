things = ['a', 'b', 'c', 'd']
print things[1]

things[1] = 'z'
print things[1]

print things


