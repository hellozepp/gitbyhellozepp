﻿while True:
    cmd = raw_input("""
1.User information
2.Setup
3.Exit
""")
    print "您输入的是",cmd

#帮群里一个新手解决的问题
