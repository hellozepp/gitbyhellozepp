def text(a, b):
    return a + b
print "Ok!"
print text(3, 5)
print text(text(3, 5), 5)
