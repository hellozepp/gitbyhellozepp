PRINT = "Hello \nWorld!"
print "%s" % PRINT
print "%r" % PRINT
