i = 0
nu = []
nu = raw_input("Please enter the number: ")
nu = int(nu)

print "The numbers: "
for num in range(i,nu):
    print num
