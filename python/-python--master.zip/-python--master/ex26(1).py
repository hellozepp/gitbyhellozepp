def secret_formula(started):
    started = 10000
    jelly_beans = started * 500
    jars = jelly_beans / 1000
    crates = jars / 100
    return jelly_beans, jars, crates
    print jelly_beans
