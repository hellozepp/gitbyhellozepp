cities['_find'] = find_city
city_found = cities['_find'](cities, state)

