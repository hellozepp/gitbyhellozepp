import time

print "Please wait.",
time.sleep(1)
print ".",
time.sleep(2)
print "."
