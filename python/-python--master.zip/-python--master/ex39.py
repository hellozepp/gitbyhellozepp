﻿class Thing(object):      #class 新的内容
    def test(hi):         #class 内部有定义的函数
        print "Hello"     #函数要求打印 "Hello"
a = Thing()               #运行class Thing()
a.test()                  #运行class 内部的 test 函数
